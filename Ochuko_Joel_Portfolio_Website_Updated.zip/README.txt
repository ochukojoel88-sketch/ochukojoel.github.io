# Ochuko Joel Personal Portfolio

This is a single-page professional portfolio website for job applications.

## Files
- index.html — complete website

## How to use
Open `index.html` in a browser to preview the site.

For a public link, upload the folder to a static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages.
